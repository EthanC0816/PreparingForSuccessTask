using UnityEngine;
using System.Collections;

public class TimeManager : MonoBehaviour
{
    public float slowdownFactor = 0.5f;
    public float slowdownLength = 2f;   

    private bool isSlowingDown = false;
    private float originalFixedDeltaTime;

    private void Start()
    {
        originalFixedDeltaTime = Time.fixedDeltaTime;
    }

    public void SlowTime()
    {
        if (!isSlowingDown)
        {
            StartCoroutine(Slowdown());
        }
    }

    private IEnumerator Slowdown()
    {
        isSlowingDown = true;

        Time.timeScale = slowdownFactor;
        Time.fixedDeltaTime = Time.timeScale * originalFixedDeltaTime;

        yield return new WaitForSecondsRealtime(slowdownLength);

        Time.timeScale = 1f;
        Time.fixedDeltaTime = originalFixedDeltaTime;

        Physics.SyncTransforms();

        isSlowingDown = false;
    }
}