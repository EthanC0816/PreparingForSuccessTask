using UnityEngine;
using System.Collections;

public class CharacterMoveFPS : MonoBehaviour
{
    [SerializeField] private CharacterController controller;
    [SerializeField] private float speed = 12f;
    [SerializeField] private float gravity = -9.81f;
    [SerializeField] private float jumpHeight = 10f;
    private Vector3 velocity;
    [SerializeField] private Transform groundCheck;
    [SerializeField] private float groundDistance = 0.4f;
    [SerializeField] private LayerMask groundMask;
    private bool isGrounded;
    [SerializeField] private float mouseSensitivity = 1000f;
    private float xRotation = 0f;
    [SerializeField] private Camera playerCamera;
    [SerializeField] private float pushForce = 10f;
    [SerializeField] private float rayDistance = 5f;
    public TimeManager timeManager;
    private float originalMouseSensitivity;

    private void Start()
    {
        controller = this.GetComponent<CharacterController>();
        Cursor.lockState = CursorLockMode.Locked;
        originalMouseSensitivity = mouseSensitivity;
    }

    private void Update()
    {
        MouseLook();
        MoveCharacter();

        if (Input.GetMouseButtonDown(0))
        {
            ForcePush();
        }
        else if (Input.GetButtonDown("E"))
        {
            timeManager.SlowTime();
            StartCoroutine(SlowMotionEffect());
        }
    }

    private void MouseLook()
    {
        float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;
        xRotation -= mouseY;
        xRotation = Mathf.Clamp(xRotation, -90f, 90f);
        playerCamera.transform.localRotation = Quaternion.Euler(xRotation, 0f, 0f);
        transform.Rotate(Vector3.up * mouseX);
    }

    private void MoveCharacter()
    {
        isGrounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundMask);

        if (isGrounded && velocity.y < 0)
        {
            velocity.y = -2f;
        }

        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");
        Vector3 move = transform.right * x + transform.forward * z;
        controller.Move(move * speed * Time.deltaTime);
        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);

        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        }
    }

    private void ForcePush()
    {
        RaycastHit hit;

        if (Physics.Raycast(playerCamera.transform.position, playerCamera.transform.forward, out hit, rayDistance))
        {
            Rigidbody rb = hit.collider.GetComponent<Rigidbody>();

            if (rb != null)
            {
                float force = pushForce;
                if (Input.GetButtonDown("E"))
                {
                    StartCoroutine(DoubleForce(rb, force));
                }
                else
                {
                    rb.AddForce(playerCamera.transform.forward * force, ForceMode.Impulse);
                }
            }
        }
    }

    private IEnumerator DoubleForce(Rigidbody rb, float initialForce)
    {
        AdjustSensitivityDuringSlowMotion(true);

        float doubledForce = initialForce * 2;
        rb.AddForce(playerCamera.transform.forward * doubledForce, ForceMode.Impulse);
        yield return new WaitForSeconds(2f);
        rb.AddForce(playerCamera.transform.forward * initialForce, ForceMode.Impulse);

        AdjustSensitivityDuringSlowMotion(false);
    }

    private void AdjustSensitivityDuringSlowMotion(bool isSlowMotion)
    {
        if (isSlowMotion)
        {
            mouseSensitivity = originalMouseSensitivity * 5f;
        }
        else
        {
            mouseSensitivity = originalMouseSensitivity;
        }
    }

    private IEnumerator SlowMotionEffect()
    {
        AdjustSensitivityDuringSlowMotion(true);
        yield return new WaitForSeconds(0.5f);
        AdjustSensitivityDuringSlowMotion(false);
    }
}
